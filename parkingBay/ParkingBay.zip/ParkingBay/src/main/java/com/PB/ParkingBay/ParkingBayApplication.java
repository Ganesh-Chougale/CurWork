package com.PB.ParkingBay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParkingBayApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParkingBayApplication.class, args);
	}

}
