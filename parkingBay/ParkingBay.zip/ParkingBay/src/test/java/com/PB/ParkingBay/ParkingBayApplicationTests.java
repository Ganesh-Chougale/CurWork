package com.PB.ParkingBay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkingBayApplicationTests {

	@Test
	void contextLoads() {
	}

}
